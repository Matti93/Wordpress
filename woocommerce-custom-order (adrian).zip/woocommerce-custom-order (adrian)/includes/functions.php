<?php
// display the extra data in the order admin panel
function modified_order_admin_view( $item_id, $item, $product ){  
        if(!(!!$item['method_title'])){
            if($item->get_subtotal() == '0'){
             wc_delete_order_item($item_id);
            }
        }
}
add_filter( 'woocommerce_before_order_itemmeta', 'modified_order_admin_view',10,3 );

add_filter( 'woocommerce_email_recipient_customer_completed_order', 'additional_customer_email_recipient', 10, 2 ); // Processing Order
add_filter( 'woocommerce_email_recipient_customer_processing_order', 'additional_customer_email_recipient', 10, 2 ); // Completed Order
function additional_customer_email_recipient($order ) {
    if ( ! is_a( $order, 'WC_Order' ) ) return $recipient;

    foreach( $order->get_items() as $item_id => $item_data ){
        if($item->get_subtotal() == '0'){
            wc_delete_order_item($item_id);
           }
    }
}
