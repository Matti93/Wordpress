=== Modified the view on orders, and emails to avoid the send of product of combos on 0 ===
Contributors: Matias Blanco
Tags: woocommerce, custom order, order, email
License: GPLv2 or Later
License URI: http://www.gnu.org/licenses/gpl-3.0.html