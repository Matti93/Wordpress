<?php
    /*
    Plugin Name: Woocommerce Custom Cart
    Description: Add textarea and select into the order template.
    Author:<a href="https://www.facebook.com/mattuqui.blanco" target="_blank">Matias Blanco</a>
    */

    require_once plugin_dir_path(__FILE__) . 'includes/functions.php';
